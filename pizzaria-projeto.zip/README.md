# 🍕 Pizzaria Projeto

Este é um projeto de sistema para pizzaria desenvolvido para a disciplina de [nome da matéria].

## 🚀 Objetivo
Criar a base de um sistema de pizzaria que poderá ser expandido ao longo do semestre, simulando um site de pedidos online.

## 🛠️ Tecnologias
- HTML5
- CSS3
- JavaScript

## 📂 Estrutura
- `index.html`: página inicial com cardápio.
- `style.css`: estilos da aplicação.
- `script.js`: lógica básica (futuras interações).
- `img/`: imagens utilizadas no projeto.

## 👨‍💻 Como rodar
1. Baixe ou clone este repositório.
2. Abra o arquivo `index.html` no navegador.
3. Pronto! 🎉

## 📌 Próximos passos
- Implementar carrinho de compras.
- Criar página de login/cadastro.
- Integrar com banco de dados (futuro).
