// Script base para futuras interações
console.log("Pizzaria THZ - Projeto inicial carregado!");